The Google+ Android sample app demonstrates how you can integrate Google Play services
in your app, and use components of the Google+ platform.

To get started, visit:
https://developers.google.com/+/mobile/android

This project has a dependency on the v4 android support libraries.  Be sure to download the
support libraries and copy the android-support-v4.jar into a libs/ directory within this sample
project.
